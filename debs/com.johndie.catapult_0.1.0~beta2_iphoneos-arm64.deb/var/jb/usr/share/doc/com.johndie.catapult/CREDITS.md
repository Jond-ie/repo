# Trebuchet for iOS — credits

Trebuchet for iOS by Jond-ie (@Jond_ie) puts the LineageOS launcher on the iOS Home Screen.

- **MakrSas**: the original Trebuchet port to iOS that this package is built on
  (https://github.com/MakrSas/Trebuchet, Apache License 2.0). Also makes Material You,
  which the launcher uses for wallpaper colours when it is installed.
- **LineageOS and the Android Open Source Project**: Trebuchet / Launcher3. The layouts, grids,
  folders, app drawer, icon shapes, motion and artwork are ported from their sources
  (Apache License 2.0). Details in NOTICE.md.
- **Roboto Flex**: Google Fonts, SIL Open Font License 1.1 (LICENSE-RobotoFlex-OFL.txt).

This package is a modified version of the Apache-2.0 works above. Its changes include
running the launcher inside SpringBoard as the Home Screen, plus widgets, page
transitions, hidden apps, web search, icon themes and fonts. The Apache License 2.0 text
is in LICENSE-Apache-2.0.txt.
