# Shared by eqelink and eqelink-fx (sourced, not run).
#
# EQE runs more than one Lua instance inside audiomxd (two of each, on an SE 2 with iOS 17), and
# every console call reaches just one of them, picked by EQE. A change sent once only lands in one
# instance. eqe_all sends it until every instance has it: each run has a token, an instance that
# already applied it answers "seen" instead of applying it again.
EQE=$JB/com.r333d.eqe/bin/eqe   # JB comes from the script that sources this file

# eqe_console CONTEXT LUA: one console call that never hangs (Triggr runs actions in order).
# Healthy calls answer in ~50 ms. While no audio plays, EQE's console path sometimes blocks for a few
# seconds: an audio-side (core / raw) call then never answers, and for a while after that even the
# daemon console doesn't. So: short limits, and a pause before trying again (measured on an SE 2).
eqe_console_once() {
	limit=1; [ "$1" = daemon ] && limit=6
	if [ -x "$JB/usr/bin/timeout" ]; then printf '%s\n' "$2" | "$JB/usr/bin/timeout" -s KILL $limit "$EQE" "$1" 2>/dev/null
	else printf '%s\n' "$2" | "$EQE" "$1" 2>/dev/null; fi
}
eqe_console() {   # the daemon: up to three tries
	for try in 1 2 3; do
		out=$(eqe_console_once "$1" "$2")
		[ -n "$out" ] && { printf '%s\n' "$out"; return 0; }
		[ "$1" = daemon ] || return 1
		sleep 1
	done
	return 1
}

# eqe_all CONTEXT INSTANCE_EXPR LUA: run LUA once in every instance of CONTEXT (core or raw).
# INSTANCE_EXPR is a table unique per instance (eqe in core, compressor in raw).
# Done when two instances have it and the last two answers were "seen"; at most 30 calls.
eqe_all() {
	token="t$$.$(date +%s)"
	applied=""; streak=0; calls=0
	while [ $calls -lt 30 ]; do
		calls=$((calls + 1))
		answer=$(eqe_console_once "$1" "local id = tostring($2):sub(-10) if __eqelink == \"$token\" then return id .. \" seen\" end $3 __eqelink = \"$token\" return id .. \" applied\"")
		case "$answer" in
			*" applied") id=${answer% applied}; case " $applied " in *" $id "*) ;; *) applied="$applied $id" ;; esac; streak=0 ;;
			*" seen") streak=$((streak + 1)) ;;
			*) sleep 1; continue ;;   # no answer: EQE's console is blocked for a moment, wait and try again
		esac
		count=$(echo $applied | wc -w)
		[ "$count" -ge 2 ] && [ $streak -ge 2 ] && return 0
	done
	[ -n "$applied" ]   # reached at least one instance
}
